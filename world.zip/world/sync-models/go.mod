module gitlab.wildberries.ru/wbwh/world/models/sprut-streams/env/sync-models.git

go 1.24.1

require (
	github.com/alta/protopatch v0.5.3
	google.golang.org/protobuf v1.36.6
)
