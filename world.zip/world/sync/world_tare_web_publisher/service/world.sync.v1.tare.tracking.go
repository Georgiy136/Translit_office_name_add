package service

import (
	"errors"
	"fmt"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_auth.git"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/rest_data"
	"gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/models"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_tare_web_publisher/clickhouse_logger"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_tare_web_publisher/entries"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_tare_web_publisher/utils"
	v001 "gitlab.wildberries.ru/wbwh/world/models/tare-saas/sync-models.git/v001"
)

const worldTareTracking = "world.sync.v1.tare.tracking"

type WorldTareTracking struct {
	entries *entries.Entries
}

func NewWorldTareTracking(e *entries.Entries) *WorldTareTracking {
	return &WorldTareTracking{
		entries: e,
	}
}

func (s *WorldTareTracking) GetDataForSync(ctx *gin.Context) ([]models.RequestDataWithSharding, error) {
	login, aErr := gocore_auth.GetLoginFromBasicAuth(ctx)
	if aErr != nil {
		cErr := rest_data.NewCustomError(aErr, "login.not_found", "login not found", "", http.StatusUnauthorized)
		ctx.AbortWithStatusJSON(http.StatusUnauthorized, cErr)
		return nil, fmt.Errorf("[%s] failed to get login: %w", worldTareTracking, aErr)
	}

	entry, exists := s.entries.Get(login)
	if !exists {
		cErr := rest_data.NewCustomError(nil, "login.entry.not_found", "no entry for this login", "", http.StatusUnprocessableEntity)
		ctx.AbortWithStatusJSON(http.StatusUnprocessableEntity, cErr)
		return nil, fmt.Errorf("[%s] no entry for login %s", worldTareTracking, login)
	}
	worldEntry := utils.GetRequestedWorldEntry(ctx)
	if worldEntry != entry {
		cErr := rest_data.NewCustomError(nil, "login.entry.not_match", "world entry headers value doesn't match allowed", "", http.StatusUnprocessableEntity)
		ctx.AbortWithStatusJSON(http.StatusUnprocessableEntity, cErr)
		return nil, fmt.Errorf("[%s] world entry headers value doesn't match allowed %s", worldTareTracking, worldEntry)
	}

	var request v001.World_Tare_Tracking
	if err := ctx.ShouldBindBodyWithJSON(&request.Data); err != nil {
		cErr := rest_data.NewCustomError(err, "validation.error", "body validation error", fmt.Sprintf("failed to bind body: %v", err), http.StatusBadRequest)
		ctx.AbortWithStatusJSON(http.StatusBadRequest, cErr)
		return nil, fmt.Errorf("[%s] failed to bind body: %w", worldTareTracking, err)
	}

	if len(request.Data) == 0 {
		cErr := rest_data.NewCustomError(errors.New("empty body"), "validation.error", "body empty", "", http.StatusBadRequest)
		ctx.AbortWithStatusJSON(http.StatusBadRequest, cErr)
		return nil, fmt.Errorf("[%s] get empty body", worldTareTracking)
	}

	msgsByCountries := make(map[string][]*v001.World_Tare_Tracking_Tare)

	for i := range request.Data {
		if request.Data[i].LifeCycleDstCountryCode == nil {
			cErr := rest_data.NewCustomError(errors.New("empty LifeCycleDstCountryCode"), "validation.error", "LifeCycleDstCountryCode empty", "", http.StatusBadRequest)
			ctx.AbortWithStatusJSON(http.StatusBadRequest, cErr)
			return nil, fmt.Errorf("[%s] get empty LifeCycleDstCountryCode", worldTareTracking)
		}
		country := strings.ToUpper(*request.Data[i].LifeCycleDstCountryCode)
		msgsByCountries[country] = append(msgsByCountries[country], request.Data[i])
	}

	if len(msgsByCountries) == 0 {
		cErr := rest_data.NewCustomError(errors.New("empty msgs by countries"), "validation.error", "body empty", "", http.StatusBadRequest)
		ctx.AbortWithStatusJSON(http.StatusBadRequest, cErr)
		return nil, fmt.Errorf("[%s] get empty msgs by countries", worldTareTracking)
	}

	if err := clickhouse_logger.LogIntoClick(&request, utils.GetReqXWhArea(ctx), utils.GetReqXWhProduct(ctx), worldTareTracking); err != nil {
		cErr := rest_data.NewCustomError(err, "internal.service_error", "internal service error", fmt.Sprintf("failed to log request: %s", err), http.StatusInternalServerError)
		ctx.AbortWithStatusJSON(http.StatusInternalServerError, cErr)
		return nil, fmt.Errorf("[%s] failed to marhal body: %w", worldTareTracking, err)
	}

	return utils.SendShardedMsg(msgsByCountries, func(msg []*v001.World_Tare_Tracking_Tare) *v001.World_Tare_Tracking {
		return &v001.World_Tare_Tracking{Data: msg}
	}, strings.Replace(utils.GetReqXWhArea(ctx), ".", "_", -1))
}
