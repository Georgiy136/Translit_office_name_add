package main

import (
	"context"

	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs/env_config"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/app"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/database/repository/connection_control"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/web_api"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_validators.git"
	"gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/publisher_by_http_batcher"
	handlers "gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/service"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_tare_web_publisher/entries"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_tare_web_publisher/service"
)

func main() {
	gocore_validators.InitializeCustomValidators()

	serviceWorker := app.NewServerScript()
	serviceWorker.InitConfigManagerDefault()
	conf := env_config.GetCommonEnvConfigs()

	var publisher publisher_by_http_batcher.HandlerRegistration
	serviceWorker.Configuration(
		connection_control.InitConnections(conf),
		func(ctx context.Context, config configs.Config) {
			e := entries.New(config)

			publisher = publisher_by_http_batcher.GetHandlerHttpRegistration(map[string]handlers.SyncHttpApi{
				"world.sync.v1.tare.declaration":       service.NewWorldTareDeclaration(e),
				"world.sync.v1.tare.tracking":          service.NewWorldTareTracking(e),
				"world.sync.v1.tare.arrived":           service.NewWorldTareArrived(e),
				"world.sync.v1.tare.external.loaded":   service.NewWorldTareExternalLoaded(e),
				"world.sync.v1.tare.external.unloaded": service.NewWorldTareExternalUnloaded(e),
				"world.sync.v1.tare.unpacking.act":     service.NewWorldTareUnpackingAct(e),
			})
			publisher.StartSync(ctx, config)
		},
	)

	serviceWorker.Tasks(web_api.StartGin(":"+conf.Port, publisher.GinHandler()))

	app.StartServer(serviceWorker)
}
