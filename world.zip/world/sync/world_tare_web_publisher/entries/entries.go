package entries

import (
	jsoniter "github.com/json-iterator/go"
	"github.com/sirupsen/logrus"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs"
)

type Entries struct {
	mp map[string]string
}

func New(config configs.Config) *Entries {
	var e Entries
	if err := jsoniter.Unmarshal(config.GetByServiceKeyRequired("world_entries"), &e.mp); err != nil {
		logrus.Panicf("cannot unmarshal world_entries: %s", err)
	}
	return &e
}

func (e *Entries) Get(login string) (string, bool) {
	entry, ok := e.mp[login]
	return entry, ok
}
