package utils

import (
	"fmt"
	"gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/models"
	"google.golang.org/protobuf/proto"
	"strings"

	"github.com/gin-gonic/gin"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_const.git/constants"
)

func GetRequestedWorldEntry(ctx *gin.Context) string {
	return strings.Join([]string{GetReqXWhArea(ctx), GetReqXWhProduct(ctx)}, ".")
}

func GetReqXWhArea(ctx *gin.Context) string {
	return ctx.GetHeader(constants.HeaderWBWHArea)
}

func GetReqXWhProduct(ctx *gin.Context) string {
	return ctx.GetHeader(constants.HeaderWBWHProduct)
}

type DataCreator[T any, M proto.Message] func(data T) M

func SendShardedMsg[T any, M proto.Message](msgsByCountries map[string]T, getData DataCreator[T, M], worldEntry string) ([]models.RequestDataWithSharding, error) {
	shardingData := make([]models.RequestDataWithSharding, 0, len(msgsByCountries))
	for country, tare := range msgsByCountries {

		rawData, err := proto.Marshal(getData(tare))
		if err != nil {
			return nil, fmt.Errorf("failed to marshal data: %w", err)
		}
		shardingData = append(shardingData, models.RequestDataWithSharding{
			ResponseBatchData: [][]byte{rawData},
			KeyShard:          map[string]struct{}{country: {}, worldEntry: {}},
		})
	}
	return shardingData, nil
}
