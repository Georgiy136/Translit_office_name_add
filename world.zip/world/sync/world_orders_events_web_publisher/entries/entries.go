package entries

import (
	jsoniter "github.com/json-iterator/go"
	"github.com/sirupsen/logrus"

	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs"
)

type Entries struct {
	mp map[string]LoginEntryMap
}

type LoginEntryMap map[string]string

func NewEntries(config configs.Config) *Entries {
	var e Entries
	e.mp = make(map[string]LoginEntryMap)
	if err := jsoniter.Unmarshal(config.GetByServiceKeyRequired("world_entries"), &e.mp); err != nil {
		logrus.Panicf("cannot unmarshal world_entries: %s", err)
	}
	return &e
}

func (e *Entries) GetEntries(channelKey, login string) (string, bool) {
	entries, ok := e.mp[channelKey]
	if ok {
		entry, isExist := entries[login]
		return entry, isExist
	}
	return "", ok
}
