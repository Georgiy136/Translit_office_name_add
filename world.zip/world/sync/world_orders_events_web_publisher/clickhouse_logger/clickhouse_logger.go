package clickhouse_logger

import (
	"fmt"
	"time"

	jsoniter "github.com/json-iterator/go"

	"gitlab.wildberries.ru/wbwh/wh-core/clickhouse.git"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore-utils-time.git/local"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs/env_config"
)

var (
	conf = env_config.GetCommonEnvConfigs()
)

type Log struct {
	Dt          time.Time `clickhouse:"dt" json:"dt"`
	WbwhArea    string    `clickhouse:"wbwh_area" json:"wbwh_area"`
	WbwhProduct string    `clickhouse:"wbwh_product" json:"wbwh_product"`
	ServerKey   string    `clickhouse:"server_key" json:"server_key"`
	Datasource  string    `clickhouse:"datasource" json:"datasource"`
	ChannelName string    `clickhouse:"channel_name" json:"channel_name"`
	JSONBytes   string    `clickhouse:"json_bytes" json:"json_bytes"`
}

func LogIntoClick(request any, area, product, channelName string) error {
	js, err := jsoniter.MarshalToString(request)
	if err != nil {
		return fmt.Errorf("cannot marshal request to json: %w", err)
	}

	err = clickhouse.Save("world_log_clickhouse_db", "direct_log.wh_world_log_sync_export_buf", "", []Log{{
		Dt:          local.ToLocalTime(time.Now()),
		WbwhArea:    area,
		WbwhProduct: product,
		ServerKey:   conf.ServerKey,
		Datasource:  conf.ServiceName,
		ChannelName: channelName,
		JSONBytes:   js,
	}})

	if err != nil {
		return fmt.Errorf("failed to insert into clickhouse: %s", err)
	}
	return nil
}
