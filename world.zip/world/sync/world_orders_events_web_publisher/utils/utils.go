package utils

import (
	"strings"

	"github.com/gin-gonic/gin"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_const.git/constants"
)

func GetRequestedWorldEntry(ctx *gin.Context) string {
	return strings.Join([]string{GetReqXWhArea(ctx), GetReqXWhProduct(ctx)}, ".")
}

func GetReqXWhArea(ctx *gin.Context) string {
	return ctx.GetHeader(constants.HeaderWBWHArea)
}

func GetReqXWhProduct(ctx *gin.Context) string {
	return ctx.GetHeader(constants.HeaderWBWHProduct)
}

func MakeDstCountryShard(dst string) string {
	return "DST_" + dst
}

func MakeSrcCountryShard(src string) string {
	return "SRC_" + src
}
