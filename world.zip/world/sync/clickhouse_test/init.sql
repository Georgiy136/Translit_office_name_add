CREATE DATABASE IF NOT EXISTS direct_log;

CREATE TABLE IF NOT EXISTS direct_log.wh_world_log_sync_export_buf
(
    dt           DateTime64(9, 'UTC'),
    wbwh_area    String,
    wbwh_product String,
    server_key   String,
    datasource   String,
    channel_name String,
    json_bytes   String
)
ENGINE = Log;
