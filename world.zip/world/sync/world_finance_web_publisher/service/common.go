package service

import (
	"context"
	"fmt"
	"github.com/gin-gonic/gin"
	jsoniter "github.com/json-iterator/go"
	"github.com/sirupsen/logrus"
	"gitlab.wildberries.ru/wbwh/wh-core/clickhouse.git"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore-utils-time.git/local"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs/env_config"
	"gitlab.wildberries.ru/wbwh/wh-core/whsync_core.git/sync_utils"
	"gitlab.wildberries.ru/wbwh/wh-core/whsync_core.git/wbsync_models"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_finance_web_publisher/models"
	clickmodels "gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_finance_web_publisher/models"
	"strings"
	"time"
)

const (
	productivityRate      = "world.sync.v1.finance.dct.productivity_rate"
	productivityCalculate = "world.sync.v1.finance.tarifficator.productivity_calculate"
	ProductHeader         = "X-Wh-Product"
	AreaHeader            = "X-Wh-Area"
)

func GetRequestedWorldEntryAndWorldTime(ctx *gin.Context) (string, string) {
	if ctx.GetHeader(AreaHeader) == "" || ctx.GetHeader(ProductHeader) == "" {
		return "", local.NowLocalRFC3339Nano()
	}
	return strings.Join([]string{ctx.GetHeader(AreaHeader), ctx.GetHeader(ProductHeader)}, "."), local.NowLocalRFC3339Nano()
}

func GetServiceZoneCountryRegion() (wbsync_models.WBSync_Msg_CountryZone, wbsync_models.WBSync_Msg_CountryRegion, wbsync_models.WBSync_Msg_CountryCode) {
	return sync_utils.GetServiceZone(), sync_utils.GetServiceRegion(), sync_utils.GetServiceCountry()
}

type LoginEntryMap map[string]string

type EntriesConfig struct {
	ChannelMap map[string]LoginEntryMap
}

type DatabaseSyncIdLoginsMap map[string]struct{}

type DatabaseSyncIdLoginsConfig struct {
	DatabaseSyncIdLogins []string `json:"logins"`
}

type ExtraConfigs struct {
	entriesConfig           EntriesConfig
	databaseSyncIdLoginsMap DatabaseSyncIdLoginsMap
}

type ClickInfoConfigStruct struct {
	ClickInfoConfig map[string]models.ClickInfo
}

func NewExtraConfigs() *ExtraConfigs {
	return &ExtraConfigs{}
}

func NewClickInfoConfigStruct() *ClickInfoConfigStruct {
	return &ClickInfoConfigStruct{make(map[string]models.ClickInfo)}
}

func (c *ExtraConfigs) Configure(_ context.Context, cfg configs.Config) {
	isExist, rawEntries := cfg.GetByServiceKey("entries")
	if !isExist {
		logrus.Panic("no entries config")
	}

	var entriesConfig EntriesConfig
	err := jsoniter.Unmarshal(rawEntries, &entriesConfig.ChannelMap)
	if err != nil {
		logrus.Panicf("can't unmarshal entries config: %v", err)
	}
	c.entriesConfig = entriesConfig
}

func (c *ClickInfoConfigStruct) Configure(_ context.Context, cfg configs.Config) {
	isExist, rawClickInfo := cfg.GetByServiceKey("clickInfo")
	if !isExist {
		logrus.Panic("no clickInfo config")
	}

	var clickInfoConfig ClickInfoConfigStruct
	err := jsoniter.Unmarshal(rawClickInfo, &clickInfoConfig.ClickInfoConfig)
	if err != nil {
		logrus.Panicf("can't unmarshal clickInfo config: %v", err)
	}
	for key, value := range clickInfoConfig.ClickInfoConfig {
		c.ClickInfoConfig[key] = value
	}
}

func (c *ExtraConfigs) CheckEntries(channel string, login string, worldEntry string) bool {
	entry, exists := c.entriesConfig.ChannelMap[channel][login]
	if exists {
		if entry != worldEntry {
			return false
		}
	}
	return exists
}

func (c *ExtraConfigs) CheckLoginForDatabaseID(login string) bool {
	_, exists := c.databaseSyncIdLoginsMap[login]
	return exists
}

func SendDataForClickLogs[T any](
	cfg *ClickInfoConfigStruct,
	req []*T,
	g *gin.Context,
	channel string,
) error {
	config := env_config.GetCommonEnvConfigs()
	var logs []clickmodels.ExportLog
	for _, v := range req {
		raw, err := jsoniter.Marshal(v)
		if err != nil {
			return fmt.Errorf("cannot marshal data for click: %w", err)
		}
		logs = append(logs, clickmodels.ExportLog{
			ChannelName: channel,
			WbwhArea:    g.GetHeader(AreaHeader),
			WbwhProduct: g.GetHeader(ProductHeader),
			ServerKey:   config.ServerKey,
			Datasource:  cfg.ClickInfoConfig[channel].DataSource,
			Dt:          time.Now().UTC().Format(time.RFC3339Nano),
			JSONBytes:   string(raw),
		})
	}
	if err := clickhouse.Save(
		cfg.ClickInfoConfig[channel].ClickDatabase,
		cfg.ClickInfoConfig[channel].ClickTable,
		channel,
		logs,
	); err != nil {
		return fmt.Errorf("cannot send data for click: %w", err)
	}
	return nil
}
