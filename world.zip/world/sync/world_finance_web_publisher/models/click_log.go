package models

type ExportLog struct {
	// Время события (DateTime64(9, 'UTC'))
	Dt string `clickhouse:"dt,datetime" json:"dt"`

	// Местоположение (String)
	WbwhArea string `clickhouse:"wbwh_area" json:"wbwh_area"`

	// Продукт (String)
	WbwhProduct string `clickhouse:"wbwh_product" json:"wbwh_product"`

	// Ключ сервера (String)
	ServerKey string `clickhouse:"server_key" json:"server_key"`

	// Источник данных (String)
	Datasource string `clickhouse:"datasource" json:"datasource"`

	// Имя канала (String)
	ChannelName string `clickhouse:"channel_name" json:"channel_name"`

	// Полный JSON события (String)
	JSONBytes string `clickhouse:"json_bytes" json:"json_bytes"`
}

type ClickInfo struct {
	DataSource    string `json:"data_source"`
	ClickTable    string `json:"click_table"`
	ClickDatabase string `json:"click_database"`
}
