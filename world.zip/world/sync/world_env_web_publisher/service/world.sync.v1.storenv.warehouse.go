package service

import (
	"fmt"
	"net/http"
	"strings"

	"gitlab.wildberries.ru/wbwh/wh-core/gocore_auth.git"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_const.git/constants"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/rest_data"
	"gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/models"
	v001 "gitlab.wildberries.ru/wbwh/world/models/storenv-saas/sync-models.git/v001"

	"google.golang.org/protobuf/proto"

	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
)

type WorldSyncV1StorenvWarehouses struct {
	extraConfigs *ExtraConfigs
	channelName  string
}

func NewWorldSyncV1StorenvWarehouses(extraConfigs *ExtraConfigs) *WorldSyncV1StorenvWarehouses {
	return &WorldSyncV1StorenvWarehouses{
		extraConfigs: extraConfigs,
		channelName:  "world.sync.v1.storenv.warehouses",
	}
}

func (w *WorldSyncV1StorenvWarehouses) GetDataForSync(g *gin.Context) ([]models.RequestDataWithSharding, error) {
	worldEntry, worldDate := GetRequestedWorldEntryAndWorldTime(g)
	if len(worldEntry) == 0 {
		cErr := rest_data.NewCustomError(ErrHeadersNotFound, "header.not_found", "required headers not found", fmt.Sprintf("required headers: %s, %s", constants.HeaderWBWHProduct, constants.HeaderWBWHArea), http.StatusBadRequest)
		g.AbortWithStatusJSON(http.StatusBadRequest, cErr)
		return nil, fmt.Errorf("%s or %s not found", constants.HeaderWBWHArea, constants.HeaderWBWHProduct)
	}

	login, err := gocore_auth.GetLoginFromBasicAuth(g)
	if err != nil {
		cErr := rest_data.NewCustomError(err, "login.not_found", "login not found", "", http.StatusUnauthorized)
		g.AbortWithStatusJSON(http.StatusUnauthorized, cErr)
		return nil, fmt.Errorf("[%s] can't get login: %w", w.channelName, err)
	}

	exist := w.extraConfigs.CheckEntries(w.channelName, login, worldEntry)
	if !exist {
		cErr := rest_data.NewCustomError(err, "login.entry.not_found", "no entry for this login and headers", "", http.StatusUnauthorized)
		g.AbortWithStatusJSON(http.StatusUnauthorized, cErr)
		return nil, fmt.Errorf("[%s] no entry for this login and headers", w.channelName)
	}

	var request v001.World_Storenv_Warehouses
	if err = g.ShouldBindBodyWith(&request.Data, binding.JSON); err != nil {
		cErr := rest_data.NewCustomError(err, "validation.error", "body validation error", fmt.Sprintf("failed to bind body: %v", err), http.StatusBadRequest)
		g.AbortWithStatusJSON(http.StatusBadRequest, cErr)
		return nil, fmt.Errorf("can not parse body: %v", err)
	}

	msgsByCountries := make(map[string][]*v001.World_Storenv_Warehouses_Warehouse)

	for i := range request.Data {
		request.Data[i].WorldEntry = worldEntry
		request.Data[i].WorldReportedDt = worldDate

		countryCode := strings.ToUpper(request.Data[i].OfficeCountryCode)
		msgsByCountries[countryCode] = append(msgsByCountries[countryCode], request.Data[i])
	}

	err = SendDataForClickLogs(&request, g, w.channelName)
	if err != nil {
		cErr := rest_data.NewCustomError(err, "internal.service_error", "internal service error", fmt.Sprintf("failed to log request: %s", err), http.StatusInternalServerError)
		g.AbortWithStatusJSON(http.StatusInternalServerError, cErr)
		return nil, err
	}

	shardingData := make([]models.RequestDataWithSharding, 0, len(msgsByCountries))
	for countryCode, data := range msgsByCountries {
		rawData, err := proto.Marshal(&v001.World_Storenv_Warehouses{Data: data})
		if err != nil {
			return nil, fmt.Errorf("failed to marshal data: %w", err)
		}

		dataWithSharding := models.RequestDataWithSharding{
			ResponseBatchData: [][]byte{rawData},
			KeyShard: map[string]struct{}{
				strings.ReplaceAll(g.GetHeader(constants.HeaderWBWHArea), ".", "_"): {},
			},
		}

		if countryCode != "" {
			dataWithSharding.KeyShard[countryCode] = struct{}{}
		}

		shardingData = append(shardingData, dataWithSharding)
	}

	return shardingData, nil
}
