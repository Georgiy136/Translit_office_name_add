package main

import (
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs/env_config"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/app"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/database/repository/connection_control"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/web_api"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_validators.git"
	"gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/publisher_by_http_handler"
	handlers "gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/service"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_env_web_publisher/service"
)

func main() {
	gocore_validators.InitializeCustomValidators()

	serviceWorker := app.NewServerScript()
	serviceWorker.InitConfigManagerDefault()
	conf := env_config.GetCommonEnvConfigs()
	extraConfig := service.NewExtraConfigs()

	worldDeliveryRoutesHandler := service.NewWorldDeliveryRoutesHandler(extraConfig)
	worldDeliveryRoutesGroupsHandler := service.NewWorldDeliveryRoutesGroupsHandler(extraConfig)
	worldDeliverySettingsHandler := service.NewWorldDeliverySettingsHandler(extraConfig)
	worldSyncV1StorenvPlaces := service.NewWorldSyncV1StorenvPlaces(extraConfig)
	worldSyncV1StorenvWarehouses := service.NewWorldSyncV1StorenvWarehouses(extraConfig)
	worldSyncV1SprutMatrix := service.NewWorldSyncV1SprutMatrix(extraConfig)

	handler := publisher_by_http_handler.GetHandlerHttpRegistration(
		map[string]handlers.SyncHttpApi{
			"world.sync.v1.env.delivery_settings.routes.publisher":        worldDeliveryRoutesHandler,
			"world.sync.v1.env.delivery_settings.routes.groups.publisher": worldDeliveryRoutesGroupsHandler,
			"world.sync.v1.env.delivery_settings.settings.publisher":      worldDeliverySettingsHandler,
			"world.sync.v1.storenv.places.publisher":                      worldSyncV1StorenvPlaces,
			"world.sync.v1.storenv.warehouses.publisher":                  worldSyncV1StorenvWarehouses,
			"world.sync.v1.sprut.office_matrix.changes.publisher":         worldSyncV1SprutMatrix,
		},
	)

	serviceWorker.Configuration(
		extraConfig.Configure,
		connection_control.InitConnections(conf),
		handler.StartSync,
	)

	serviceWorker.Tasks(web_api.StartGin(":"+conf.Port, handler.GinHandler()))

	app.StartServer(serviceWorker)
}
