package main

import (
	"context"

	"github.com/sirupsen/logrus"
	nats_client "gitlab.wildberries.ru/wbwh/wh-core/gocore_nats_request_reply.git/client"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs/env_config"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/app"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/database/repository/connection_control"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/web_api"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_validators.git"
	"gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/publisher_by_http_batcher"
	handlers "gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/service"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_goodsonplace_web_publisher/entries"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_goodsonplace_web_publisher/service/v1"
	v2 "gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_goodsonplace_web_publisher/service/v2"
)

func main() {
	gocore_validators.InitializeCustomValidators()

	serviceWorker := app.NewServerScript()
	serviceWorker.InitConfigManagerDefault()
	conf := env_config.GetCommonEnvConfigs()

	var publisher publisher_by_http_batcher.HandlerRegistration
	serviceWorker.Configuration(
		connection_control.InitConnections(conf),
		func(ctx context.Context, config configs.Config) {
			e := entries.New(config)

			var nc *nats_client.NatsClient
			if exists, _ := config.GetByServiceKey("nats_lt_backup"); exists {
				nc = nats_client.NewNatsClient()
				nc.ConfigureWithCustomName("nats_lt_backup")(ctx, config)
			} else {
				logrus.Debug("backup saving is disabled")
			}

			publisher = publisher_by_http_batcher.GetHandlerHttpRegistration(map[string]handlers.SyncHttpApi{
				"world.sync.v1.goodsonplace.invent_or_create": v1.NewWorldGoodsOnPlaceInventOrCreate(e),
				"world.sync.v1.goodsonplace.release":          v1.NewWorldGoodsOnPlaceRelease(e),
				"world.sync.v1.goodsonplace.state":            v1.NewWorldGoodsOnPlaceState(e),

				"world.sync.v2.goodsonplace.invent":         v2.NewWorldGoodsOnPlaceInvent(e, nc),
				"world.sync.v2.goodsonplace.create":         v2.NewWorldGoodsOnPlaceCreate(e, nc),
				"world.sync.v2.goodsonplace.release":        v2.NewWorldGoodsOnPlaceRelease(e, nc),
				"world.sync.v2.goodsonplace.state":          v2.NewWorldGoodsOnPlaceState(e, nc),
				"world.sync.v2.goodsonplace.country_change": v2.NewWorldGoodsOnPlaceCountryChange(e, nc),
			})
			publisher.StartSync(ctx, config)
		},
	)

	serviceWorker.Tasks(web_api.StartGin(":"+conf.Port, publisher.GinHandler()))
	app.StartServer(serviceWorker)
}
