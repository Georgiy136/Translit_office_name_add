package v1

import (
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore-utils-time.git/local"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_auth.git"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/rest_data"
	"gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/models"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_goodsonplace_web_publisher/clickhouse_logger"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_goodsonplace_web_publisher/entries"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_goodsonplace_web_publisher/utils"
	v001 "gitlab.wildberries.ru/wbwh/world/models/goodsonplace/sync-models.git/v001"
	"google.golang.org/protobuf/proto"
)

const worldGoodsOnPlaceInventOrCreate = "world.sync.v1.goodsonplace.invent_or_create"

type WorldGoodsOnPlaceInventOrCreate struct {
	entries *entries.Entries
}

func NewWorldGoodsOnPlaceInventOrCreate(e *entries.Entries) *WorldGoodsOnPlaceInventOrCreate {
	return &WorldGoodsOnPlaceInventOrCreate{
		entries: e,
	}
}

func (s *WorldGoodsOnPlaceInventOrCreate) GetDataForSync(ctx *gin.Context) ([]models.RequestDataWithSharding, error) {
	login, aErr := gocore_auth.GetLoginFromBasicAuth(ctx)
	if aErr != nil {
		cErr := rest_data.NewCustomError(aErr, "login.not_found", "login not found", "", http.StatusUnauthorized)
		ctx.AbortWithStatusJSON(http.StatusUnauthorized, cErr)
		return nil, fmt.Errorf("[%s] failed to get login: %w", worldGoodsOnPlaceInventOrCreate, aErr)
	}

	entry, exists := s.entries.Get(login)
	if !exists {
		cErr := rest_data.NewCustomError(nil, "login.entry.not_found", "no entry for this login", "", http.StatusUnprocessableEntity)
		ctx.AbortWithStatusJSON(http.StatusUnprocessableEntity, cErr)
		return nil, fmt.Errorf("[%s] no entry for login %s", worldGoodsOnPlaceInventOrCreate, login)
	}
	worldEntry := utils.GetRequestedWorldEntry(ctx)
	if worldEntry != entry {
		cErr := rest_data.NewCustomError(nil, "login.entry.not_match", "world entry headers value doesn't match allowed", "", http.StatusUnprocessableEntity)
		ctx.AbortWithStatusJSON(http.StatusUnprocessableEntity, cErr)
		return nil, fmt.Errorf("[%s] world entry headers value doesn't match allowed %s", worldGoodsOnPlaceInventOrCreate, worldEntry)
	}

	var request v001.World_GoodsOnPlace_InventOrCreate
	switch ctx.ContentType() {
	case binding.MIMEJSON:
		if err := ctx.ShouldBindBodyWith(&request.Data, binding.JSON); err != nil {
			cErr := rest_data.NewCustomError(err, "validation.error", "body validation error", fmt.Sprintf("failed to bind body: %v", err), http.StatusBadRequest)
			ctx.AbortWithStatusJSON(http.StatusBadRequest, cErr)
			return nil, fmt.Errorf("[%s] failed to bind body: %w", worldGoodsOnPlaceInventOrCreate, err)
		}
	case binding.MIMEPROTOBUF:
		if err := ctx.ShouldBindBodyWith(&request, binding.ProtoBuf); err != nil {
			cErr := rest_data.NewCustomError(err, "validation.error", "body validation error", fmt.Sprintf("failed to bind body: %v", err), http.StatusBadRequest)
			ctx.AbortWithStatusJSON(http.StatusBadRequest, cErr)
			return nil, fmt.Errorf("[%s] failed to bind body: %w", worldGoodsOnPlaceInventOrCreate, err)
		}
		if err := binding.Validator.ValidateStruct(&request); err != nil {
			cErr := rest_data.NewCustomError(err, "validation.error", "body validation error", fmt.Sprintf("failed to validate body: %v", err), http.StatusBadRequest)
			ctx.AbortWithStatusJSON(http.StatusBadRequest, cErr)
			return nil, fmt.Errorf("[%s] failed to validate body: %w", worldGoodsOnPlaceInventOrCreate, err)
		}
	default:
		err := fmt.Errorf("wrong content type, expected application/json or application/octet-stream, got %s", ctx.ContentType())
		cErr := rest_data.NewCustomError(err, "validation.error", "body validation error", fmt.Sprintf("failed to validate body: %v", err), http.StatusBadRequest)
		ctx.AbortWithStatusJSON(http.StatusBadRequest, cErr)
		return nil, fmt.Errorf("[%s] failed to validate body: %w", worldGoodsOnPlaceInventOrCreate, err)
	}

	for _, el := range request.Data {
		el.WorldEntry = entry
		el.WorldReportedDt = local.NowLocalRFC3339Nano()
	}

	pb, err := proto.Marshal(&request)
	if err != nil {
		cErr := rest_data.NewCustomError(err, "internal.service_error", "internal service error", fmt.Sprintf("failed to marshal body: %s", err), http.StatusInternalServerError)
		ctx.AbortWithStatusJSON(http.StatusInternalServerError, cErr)
		return nil, fmt.Errorf("[%s] failed to marhal body: %w", worldGoodsOnPlaceInventOrCreate, err)
	}

	if err = clickhouse_logger.LogIntoClick(&request, utils.GetReqXWhArea(ctx), utils.GetReqXWhProduct(ctx), worldGoodsOnPlaceInventOrCreate); err != nil {
		cErr := rest_data.NewCustomError(err, "internal.service_error", "internal service error", fmt.Sprintf("failed to log request: %s", err), http.StatusInternalServerError)
		ctx.AbortWithStatusJSON(http.StatusInternalServerError, cErr)
		return nil, fmt.Errorf("[%s] failed to marhal body: %w", worldGoodsOnPlaceInventOrCreate, err)
	}
	return []models.RequestDataWithSharding{
		{
			ResponseBatchData: [][]byte{pb},
		},
	}, nil
}
