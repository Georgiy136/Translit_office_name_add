package v2

import (
	"context"
	"fmt"
	"net/http"

	handler_core "gitlab.wildberries.ru/wbwh/wh-core/gocore_nats_request_reply.git/client"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/rest_data/pb"
	"google.golang.org/protobuf/proto"
)

type ShardStruct struct {
	Country   string
	WorldArea string
}

func SendToBackup[T proto.Message](ctx context.Context, nc *handler_core.NatsClient, subject string, data T) error {
	rawData, err := proto.Marshal(data)
	if err != nil {
		return fmt.Errorf("cannot marshal data to proto, err: %v, subj: %v", err, subject)
	}
	msg, err := nc.RequestWithContext(ctx, subject, rawData)
	if err != nil {
		return fmt.Errorf("cannot send to backup, err: %v, subj: %v", err, subject)
	}
	var rd pb.RestData
	if msg != nil && msg.Data != nil {
		if err = proto.Unmarshal(msg.Data, &rd); err != nil {
			return fmt.Errorf("cannot unmarshal response from backup to rest_data.proto, err: %v, subj: %v, data: %s", err, subject, msg.Data)
		}
		if rd.ResultCode != http.StatusNoContent {
			return fmt.Errorf("unexpected response from backup to rest_data.proto, code: %v, subj: %v", rd.ResultCode, subject)
		}
		return nil
	}
	return fmt.Errorf("response is nil from backup, subj: %v", subject)
}
