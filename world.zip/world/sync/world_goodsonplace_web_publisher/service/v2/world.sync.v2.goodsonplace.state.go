package v2

import (
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore-utils-time.git/local"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_auth.git"
	nats_client "gitlab.wildberries.ru/wbwh/wh-core/gocore_nats_request_reply.git/client"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/rest_data"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git/errors/errors_keys"
	"gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/models"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_goodsonplace_web_publisher/clickhouse_logger"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_goodsonplace_web_publisher/entries"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_goodsonplace_web_publisher/utils"
	v001 "gitlab.wildberries.ru/wbwh/world/models/goodsonplace/sync-models.git/v001"
	"google.golang.org/protobuf/proto"
)

const worldGoodsOnPlaceState = "world.sync.v2.goodsonplace.state"

type WorldGoodsOnPlaceState struct {
	entries *entries.Entries
	nc      *nats_client.NatsClient
}

func NewWorldGoodsOnPlaceState(e *entries.Entries, nc *nats_client.NatsClient) *WorldGoodsOnPlaceState {
	return &WorldGoodsOnPlaceState{
		entries: e,
		nc:      nc,
	}
}

func (s *WorldGoodsOnPlaceState) GetDataForSync(ctx *gin.Context) ([]models.RequestDataWithSharding, error) {
	login, aErr := gocore_auth.GetLoginFromBasicAuth(ctx)
	if aErr != nil {
		cErr := rest_data.NewCustomError(aErr, "login.not_found", "login not found", "", http.StatusUnauthorized)
		ctx.AbortWithStatusJSON(http.StatusUnauthorized, cErr)
		return nil, fmt.Errorf("[%s] failed to get login: %w", worldGoodsOnPlaceState, aErr)
	}
	inWhitelist := s.entries.InWhitelist(login)

	entry, exists := s.entries.Get(login)
	if !exists && !inWhitelist {
		cErr := rest_data.NewCustomError(nil, "login.entry.not_found", "no entry for this login", "", http.StatusUnprocessableEntity)
		ctx.AbortWithStatusJSON(http.StatusUnprocessableEntity, cErr)
		return nil, fmt.Errorf("[%s] no entry for login %s", worldGoodsOnPlaceState, login)
	}
	worldEntry := utils.GetRequestedWorldEntry(ctx)
	if worldEntry != entry && !inWhitelist {
		cErr := rest_data.NewCustomError(nil, "login.entry.not_match", "world entry headers value doesn't match allowed", "", http.StatusUnprocessableEntity)
		ctx.AbortWithStatusJSON(http.StatusUnprocessableEntity, cErr)
		return nil, fmt.Errorf("[%s] world entry headers value doesn't match allowed %s", worldGoodsOnPlaceState, worldEntry)
	}

	var request v001.World_GoodsOnPlace_State
	switch ctx.ContentType() {
	case binding.MIMEJSON:
		if err := ctx.ShouldBindBodyWith(&request.Data, binding.JSON); err != nil {
			cErr := rest_data.NewCustomError(err, "validation.error", "body validation error", fmt.Sprintf("failed to bind body: %v", err), http.StatusBadRequest)
			ctx.AbortWithStatusJSON(http.StatusBadRequest, cErr)
			return nil, fmt.Errorf("[%s] failed to bind body: %w", worldGoodsOnPlaceState, err)
		}
	case binding.MIMEPROTOBUF:
		if err := ctx.ShouldBindBodyWith(&request, binding.ProtoBuf); err != nil {
			cErr := rest_data.NewCustomError(err, "validation.error", "body validation error", fmt.Sprintf("failed to bind body: %v", err), http.StatusBadRequest)
			ctx.AbortWithStatusJSON(http.StatusBadRequest, cErr)
			return nil, fmt.Errorf("[%s] failed to bind body: %w", worldGoodsOnPlaceState, err)
		}
		if err := binding.Validator.ValidateStruct(&request); err != nil {
			cErr := rest_data.NewCustomError(err, "validation.error", "body validation error", fmt.Sprintf("failed to validate body: %v", err), http.StatusBadRequest)
			ctx.AbortWithStatusJSON(http.StatusBadRequest, cErr)
			return nil, fmt.Errorf("[%s] failed to validate body: %w", worldGoodsOnPlaceState, err)
		}
	default:
		err := fmt.Errorf("wrong content type, expected application/json or application/octet-stream, got %s", ctx.ContentType())
		cErr := rest_data.NewCustomError(err, "validation.error", "body validation error", fmt.Sprintf("failed to validate body: %v", err), http.StatusBadRequest)
		ctx.AbortWithStatusJSON(http.StatusBadRequest, cErr)
		return nil, fmt.Errorf("[%s] failed to validate body: %w", worldGoodsOnPlaceState, err)
	}

	mapBySrcCountry := make(map[ShardStruct][]*v001.World_GoodsOnPlace_State_Goods)
	for _, el := range request.Data {
		area, err := utils.GetArea(el.WorldEntry)
		if err != nil {
			cErr := rest_data.NewCustomError(nil, "validation.error", err.Error(), "", http.StatusUnprocessableEntity)
			ctx.AbortWithStatusJSON(http.StatusUnprocessableEntity, cErr)
			return nil, fmt.Errorf("[%s] %s", worldGoodsOnPlaceState, err.Error())
		}

		shard := ShardStruct{
			Country:   el.OfficeCountryCode,
			WorldArea: area,
		}
		if !inWhitelist {
			shard.WorldArea = utils.GetAreaShard(ctx)
			if area != shard.WorldArea {
				cErr := rest_data.NewCustomError(nil, "validation.error", "world entry area doesn't belong to this country", "", http.StatusUnprocessableEntity)
				ctx.AbortWithStatusJSON(http.StatusUnprocessableEntity, cErr)
				return nil, fmt.Errorf("[%s] world entry area doesn't belong to this country", worldGoodsOnPlaceState)
			}
		}
		el.WorldReportedDt = local.NowLocalRFC3339Nano()
		mapBySrcCountry[shard] = append(mapBySrcCountry[shard], el)
	}

	shards := make([]models.RequestDataWithSharding, 0, len(mapBySrcCountry))
	for shard, data := range mapBySrcCountry {
		pData, err := proto.Marshal(&v001.World_GoodsOnPlace_State{Data: data})
		if err != nil {
			return nil, fmt.Errorf("[%s] failed to marshal data: %w", worldGoodsOnPlaceCreate, err)
		}
		shards = append(shards, models.RequestDataWithSharding{
			ResponseBatchData: [][]byte{pData},
			KeyShard: map[string]struct{}{
				utils.MakeSrcCountryShard(shard.Country): {},
				shard.WorldArea:                          {},
			},
		})
	}

	if err := clickhouse_logger.LogIntoClick(&request, utils.GetReqXWhArea(ctx), utils.GetReqXWhProduct(ctx), worldGoodsOnPlaceState); err != nil {
		cErr := rest_data.NewCustomError(err, "internal.service_error", "internal service error", fmt.Sprintf("failed to log request: %s", err), http.StatusInternalServerError)
		ctx.AbortWithStatusJSON(http.StatusInternalServerError, cErr)
		return nil, fmt.Errorf("[%s] failed to marhal body: %w", worldGoodsOnPlaceState, err)
	}

	if s.nc != nil {
		if err := SendToBackup[*v001.World_GoodsOnPlace_State](ctx, s.nc, worldGoodsOnPlaceState, &request); err != nil {
			cErr := rest_data.NewCustomError(nil, errors_keys.ErrorKeyServiceError, fmt.Sprintf("[SendToBackup], error: %v", err), "", http.StatusInternalServerError)
			ctx.AbortWithStatusJSON(http.StatusInternalServerError, cErr)
			return nil, fmt.Errorf("[%s] %w", worldGoodsOnPlaceState, err)
		}
	}

	return shards, nil
}
