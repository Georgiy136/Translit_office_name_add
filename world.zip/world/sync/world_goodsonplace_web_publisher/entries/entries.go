package entries

import (
	jsoniter "github.com/json-iterator/go"
	"github.com/sirupsen/logrus"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs"
)

type Entries struct {
	loginsEntry     map[string]string
	whitelistLogins map[string]struct{}
}

func New(config configs.Config) *Entries {
	var e struct {
		LoginsEntry     map[string]string `json:"logins_entry"`
		WhitelistLogins []string          `json:"whitelist_logins"`
	}
	if err := jsoniter.Unmarshal(config.GetByServiceKeyRequired("world_entries"), &e); err != nil {
		logrus.Panicf("cannot unmarshal world_entries: %s", err)
	}
	entries := Entries{
		loginsEntry:     make(map[string]string),
		whitelistLogins: make(map[string]struct{}),
	}
	entries.loginsEntry = e.LoginsEntry
	for _, login := range e.WhitelistLogins {
		entries.whitelistLogins[login] = struct{}{}
	}
	return &entries
}

func (e *Entries) Get(login string) (string, bool) {
	entry, ok := e.loginsEntry[login]
	return entry, ok
}

func (e *Entries) InWhitelist(login string) bool {
	_, ok := e.whitelistLogins[login]
	return ok
}
