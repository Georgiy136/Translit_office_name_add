package services

import (
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore-utils-time.git/local"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_auth.git"
	"gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/models"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_supply_web_publisher/clickhouse_logger"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_supply_web_publisher/entries"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_supply_web_publisher/utils"
	v001 "gitlab.wildberries.ru/wbwh/world/models/supply-saas/sync-models.git/v001"
	"google.golang.org/protobuf/proto"
)

type WorldSupplyExtIDScanDictionary struct {
	channelKey string
	entries    *entries.Entries
}

func NewWorldSupplyExtIDScanDictionary(e *entries.Entries) *WorldSupplyExtIDScanDictionary {
	const key = "world.sync.v1.supply.ext_id_scan_dictionary"

	return &WorldSupplyExtIDScanDictionary{
		channelKey: key,
		entries:    e,
	}
}

func (s *WorldSupplyExtIDScanDictionary) GetDataForSync(ctx *gin.Context) ([]models.RequestDataWithSharding, error) {
	login, err := gocore_auth.GetLoginFromBasicAuth(ctx)
	if err != nil {
		abortCtxWithError(ctx, http.StatusUnauthorized, err, "login.not_found", "login not found", "")
		return nil, fmt.Errorf("[%s] failed to get login: %w", s.channelKey, err)
	}

	inWhiteList := s.entries.InWhitelist(login)
	entry, exists := s.entries.Get(login)
	if !exists && !inWhiteList {
		abortCtxWithError(ctx, http.StatusUnprocessableEntity, nil, "entry.not_found", "no entry for this login", "")
		return nil, fmt.Errorf("[%s] failed to get entry for login: %s", s.channelKey, login)
	}

	worldEntry := utils.GetRequestedWorldEntry(ctx)
	if worldEntry != entry && !inWhiteList {
		abortCtxWithError(ctx, http.StatusUnprocessableEntity, nil, "entry.not_match", "world entry headers value doesn't match allowed", "")
		return nil, fmt.Errorf("[%s] world entry headers value doesn't match allowed: %s", s.channelKey, worldEntry)
	}

	var request v001.World_Supply_ExtIdScanDictionary
	switch ctx.ContentType() {
	case binding.MIMEJSON:
		if err = ctx.ShouldBindBodyWith(&request.Data, binding.JSON); err != nil {
			abortCtxWithError(ctx, http.StatusBadRequest, err, "validation.error", "body validation error", fmt.Sprintf("failed to bind body: %v", err))
			return nil, fmt.Errorf("[%s] failed to bind body: %w", s.channelKey, err)
		}
	case binding.MIMEPROTOBUF:
		if err = ctx.ShouldBindBodyWith(&request, binding.ProtoBuf); err != nil {
			abortCtxWithError(ctx, http.StatusBadRequest, err, "validation.error", "body validation error", fmt.Sprintf("failed to bind body: %v", err))
			return nil, fmt.Errorf("[%s] failed to bind body: %w", s.channelKey, err)
		}
		if err = binding.Validator.ValidateStruct(&request); err != nil {
			abortCtxWithError(ctx, http.StatusBadRequest, err, "validation.error", "body validation error", fmt.Sprintf("failed to validate body: %v", err))
			return nil, fmt.Errorf("[%s] failed to validate body: %w", s.channelKey, err)
		}
	default:
		err = fmt.Errorf("wrong content type, expected application/json or application/x-protobuf, got %s", ctx.ContentType())
		abortCtxWithError(ctx, http.StatusBadRequest, err, "validation.error", "body validation error", "")
		return nil, fmt.Errorf("[%s] failed to validate body: %w", s.channelKey, err)
	}

	if len(request.Data) == 0 {
		return nil, nil
	}

	for _, el := range request.Data {
		if el.WorldEntry == nil || len(*el.WorldEntry) == 0 {
			el.WorldEntry = &worldEntry
		}

		reportedDt := local.NowLocalRFC3339Nano()
		el.WorldReportedDt = &reportedDt
	}

	pb, err := proto.Marshal(&request)
	if err != nil {
		abortCtxWithError(ctx, http.StatusInternalServerError, err, "internal.service_error", "internal service error", "")
		return nil, fmt.Errorf("[%s] failed to marshal data: %w", s.channelKey, err)
	}

	if err = clickhouse_logger.LogIntoClick(&request, utils.GetReqXWhArea(ctx), utils.GetReqXWhProduct(ctx), s.channelKey); err != nil {
		abortCtxWithError(ctx, http.StatusInternalServerError, err, "internal.service_error", "internal service error", "")
		return nil, fmt.Errorf("[%s] failed to log request: %w", s.channelKey, err)
	}

	return []models.RequestDataWithSharding{{
		ResponseBatchData: [][]byte{pb},
	}}, nil
}
