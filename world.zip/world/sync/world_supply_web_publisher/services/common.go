package services

type ShardStruct struct {
	Country   string
	WorldArea string
}
