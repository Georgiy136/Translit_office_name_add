package services

import (
	"fmt"
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore-utils-time.git/local"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_auth.git"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/rest_data"
	"gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/models"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_supply_web_publisher/clickhouse_logger"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_supply_web_publisher/entries"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_supply_web_publisher/utils"
	v001 "gitlab.wildberries.ru/wbwh/world/models/supply-saas/sync-models.git/v001"
	"google.golang.org/protobuf/proto"
)

type WorldSupplySuppliesChanges struct {
	channelKey string
	entries    *entries.Entries
}

func NewWorldSupplySuppliesChanges(e *entries.Entries) *WorldSupplySuppliesChanges {
	const key = "world.sync.v1.supply.supplies.changes"

	return &WorldSupplySuppliesChanges{
		channelKey: key,
		entries:    e,
	}
}

func (s *WorldSupplySuppliesChanges) GetDataForSync(ctx *gin.Context) ([]models.RequestDataWithSharding, error) {
	const marketplaceSupplyType = "SBS"

	login, err := gocore_auth.GetLoginFromBasicAuth(ctx)
	if err != nil {
		abortCtxWithError(ctx, http.StatusUnauthorized, err, "login.not_found", "login not found", "")
		return nil, fmt.Errorf("[%s] failed to get login: %w", s.channelKey, err)
	}

	inWhiteList := s.entries.InWhitelist(login)
	entry, exists := s.entries.Get(login)
	if !exists && !inWhiteList {
		abortCtxWithError(ctx, http.StatusUnprocessableEntity, nil, "entry.not_found", "no entry for this login", "")
		return nil, fmt.Errorf("[%s] failed to get entry for login: %s", s.channelKey, login)
	}

	worldEntry := utils.GetRequestedWorldEntry(ctx)
	if worldEntry != entry && !inWhiteList {
		abortCtxWithError(ctx, http.StatusUnprocessableEntity, nil, "entry.not_match", "world entry headers value doesn't match allowed", "")
		return nil, fmt.Errorf("[%s] world entry headers value doesn't match allowed: %s", s.channelKey, worldEntry)
	}

	var request v001.World_Supply_SuppliesChanges
	switch ctx.ContentType() {
	case binding.MIMEJSON:
		if err = ctx.ShouldBindBodyWith(&request.Data, binding.JSON); err != nil {
			abortCtxWithError(ctx, http.StatusBadRequest, err, "validation.error", "body validation error", fmt.Sprintf("failed to bind body: %v", err))
			return nil, fmt.Errorf("[%s] failed to bind body: %w", s.channelKey, err)
		}
	case binding.MIMEPROTOBUF:
		if err = ctx.ShouldBindBodyWith(&request, binding.ProtoBuf); err != nil {
			abortCtxWithError(ctx, http.StatusBadRequest, err, "validation.error", "body validation error", fmt.Sprintf("failed to bind body: %v", err))
			return nil, fmt.Errorf("[%s] failed to bind body: %w", s.channelKey, err)
		}
		if err = binding.Validator.ValidateStruct(&request); err != nil {
			abortCtxWithError(ctx, http.StatusBadRequest, err, "validation.error", "body validation error", fmt.Sprintf("failed to validate body: %v", err))
			return nil, fmt.Errorf("[%s] failed to validate body: %w", s.channelKey, err)
		}
	default:
		err = fmt.Errorf("wrong content type, expected application/json or application/x-protobuf, got %s", ctx.ContentType())
		abortCtxWithError(ctx, http.StatusBadRequest, err, "validation.error", "body validation error", "")
		return nil, fmt.Errorf("[%s] failed to validate body: %w", s.channelKey, err)
	}

	mapBySrcCountry := make(map[ShardStruct][]*v001.World_Supply_SuppliesChanges_SupplyChange)
	for _, el := range request.Data {
		if len(el.WorldEntry) == 0 {
			el.WorldEntry = worldEntry
		}
		el.WorldReportedDt = local.NowLocalRFC3339Nano()

		area, err := utils.GetArea(el.WorldEntry)
		if err != nil {
			abortCtxWithError(ctx, http.StatusUnprocessableEntity, nil, "validation.error", err.Error(), "")
			return nil, fmt.Errorf("[%s] failed to get area: %s", s.channelKey, err.Error())
		}

		if el.Ext == nil {
			errMsg := "received empty extension of supply change"
			abortCtxWithError(ctx, http.StatusUnprocessableEntity, nil, "validation.error", errMsg, "")
			return nil, fmt.Errorf("[%s] %s", s.channelKey, errMsg)
		}

		var shardCountry string
		if el.SupplyType != marketplaceSupplyType && el.Ext.PlanCountryCode == nil {
			errMsg := fmt.Sprintf("received empty plan_country_code for supply_type: %s", el.SupplyType)
			abortCtxWithError(ctx, http.StatusUnprocessableEntity, nil, "validation.error", errMsg, "")
			return nil, fmt.Errorf("[%s] %s", s.channelKey, errMsg)
		}
		if el.Ext.PlanCountryCode != nil {
			shardCountry = *el.Ext.PlanCountryCode
		}

		shard := ShardStruct{
			Country:   shardCountry,
			WorldArea: area,
		}

		mapBySrcCountry[shard] = append(mapBySrcCountry[shard], el)
	}

	shards := make([]models.RequestDataWithSharding, 0, len(mapBySrcCountry))
	for shard, data := range mapBySrcCountry {
		pb, err := proto.Marshal(&v001.World_Supply_SuppliesChanges{Data: data})
		if err != nil {
			abortCtxWithError(ctx, http.StatusInternalServerError, err, "internal.service_error", "internal service error", "")
			return nil, fmt.Errorf("[%s] failed to marshal data: %w", s.channelKey, err)
		}
		shards = append(shards, models.RequestDataWithSharding{
			ResponseBatchData: [][]byte{pb},
			KeyShard: map[string]struct{}{
				utils.MakeDstCountryShard(shard.Country): {},
				shard.WorldArea:                          {},
			},
		})
	}

	if err := clickhouse_logger.LogIntoClick(&request, utils.GetReqXWhArea(ctx), utils.GetReqXWhProduct(ctx), s.channelKey); err != nil {
		abortCtxWithError(ctx, http.StatusInternalServerError, err, "internal.service_error", "internal service error", "")
		return nil, fmt.Errorf("[%s] failed to log request: %w", s.channelKey, err)
	}

	return shards, nil
}

func abortCtxWithError(ctx *gin.Context, statusCode int, err error, key, msg, details string) {
	cErr := rest_data.NewCustomError(err, key, msg, details, statusCode)
	ctx.AbortWithStatusJSON(statusCode, cErr)
}
