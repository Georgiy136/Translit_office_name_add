package utils

import (
	"errors"
	"strings"

	"github.com/gin-gonic/gin"

	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_const.git/constants"
)

func GetRequestedWorldEntry(ctx *gin.Context) string {
	return strings.Join([]string{GetReqXWhArea(ctx), GetReqXWhProduct(ctx)}, ".")
}

func GetReqXWhArea(ctx *gin.Context) string {
	return ctx.GetHeader(constants.HeaderWBWHArea)
}

func GetReqXWhProduct(ctx *gin.Context) string {
	return ctx.GetHeader(constants.HeaderWBWHProduct)
}

func MakeDstCountryShard(dst string) string {
	const (
		emptyString      = ""
		marketplaceShard = "MP"
	)
	if dst == emptyString {
		return marketplaceShard
	}
	return "DST_" + dst
}

func GetArea(entry string) (string, error) {
	entryAndZone := strings.Split(entry, ".")
	switch len(entryAndZone) {
	case 1: // sprut
		return "", errors.New("no geozone found in entry: " + entry)
	case 3, 4: // FR.GEO.R1 || FR.GEO.R1.sprut
		return strings.Join(entryAndZone[:3], "_"), nil
	}
	return "", errors.New("wrong entry parts count: " + entry)
}
