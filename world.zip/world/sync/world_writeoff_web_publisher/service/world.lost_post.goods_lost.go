package service

import (
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_auth.git"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_const.git/constants"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/rest_data"
	"gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/models"
	"gitlab.wildberries.ru/wbwh/wh-core/whsync_core.git/wbsync_models"
	v001 "gitlab.wildberries.ru/wbwh/world/models/writeoff/sync-models.git/v001"
	"google.golang.org/protobuf/proto"
	"net/http"
)

const goodsLost = "world.sync.v1.lostpost.goods.lost.by_office"

type WorldLostPostGoodsLostHandler struct {
	extraConfigs    *ExtraConfigs
	clickInfoConfig *ClickInfoConfigStruct
}

func NewWorldLostPostGoodsLostHandler(extraConfigs *ExtraConfigs, clickInfoConfig *ClickInfoConfigStruct) *WorldLostPostGoodsLostHandler {
	return &WorldLostPostGoodsLostHandler{
		extraConfigs:    extraConfigs,
		clickInfoConfig: clickInfoConfig,
	}
}

func (w *WorldLostPostGoodsLostHandler) GetDataForSync(g *gin.Context) ([]models.RequestDataWithSharding, error) {
	worldEntry, worldDate := GetRequestedWorldEntryAndWorldTime(g)
	if worldEntry == "" {
		return nil, fmt.Errorf("%s or %s not found", constants.HeaderWBWHArea, constants.HeaderWBWHProduct)
	}

	login, err := gocore_auth.GetLoginFromBasicAuth(g)
	if err != nil {
		cErr := rest_data.NewCustomError(err, "login.not_found", "login not found", "", http.StatusUnauthorized)
		g.AbortWithStatusJSON(http.StatusUnauthorized, cErr)
		return nil, fmt.Errorf("[%s] can't get login: %w", goodsLost, err)
	}
	exist := w.extraConfigs.CheckEntries(goodsLost, login, worldEntry)
	if !exist {
		cErr := rest_data.NewCustomError(err, "login.entry.not_found", "no entry for this login and headers", "", http.StatusUnauthorized)
		g.AbortWithStatusJSON(http.StatusUnauthorized, cErr)
		return nil, fmt.Errorf("[%s] no entry for this login and headers", goodsLost)
	}

	request := v001.World_LostPost_GoodsLostByOffice{
		Data: []*v001.World_LostPost_GoodsLostByOffice_GoodsLost{},
	}
	if err := g.ShouldBindBodyWith(&request, binding.JSON); err != nil {
		g.AbortWithStatusJSON(http.StatusBadRequest, gin.H{"error": "Validation error. BODY validation error"})
		return nil, fmt.Errorf("can not parse body: %v", err)
	}
	for i := range request.Data {
		request.Data[i].WorldEntry = worldEntry
		request.Data[i].WorldReportedDt = worldDate
	}

	err = SendDataForClickLogs(w.clickInfoConfig, request.Data, g, goodsLost)
	if err != nil {
		return nil, err
	}
	rawData, err := proto.Marshal(&request)
	if err != nil {
		return nil, fmt.Errorf("request.Marshal error")
	}
	sz, sr, sc := GetServiceZoneCountryRegion()

	return []models.RequestDataWithSharding{{
		CountryZone: map[wbsync_models.WBSync_Msg_CountryZone]struct{}{
			sz: {},
		},
		CountryRegion: map[wbsync_models.WBSync_Msg_CountryRegion]struct{}{
			sr: {},
		},
		Countries: map[wbsync_models.WBSync_Msg_CountryCode]struct{}{
			sc: {},
		},
		ResponseData: rawData,
	}}, nil
}
