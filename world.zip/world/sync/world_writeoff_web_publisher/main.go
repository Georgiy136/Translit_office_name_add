package main

import (
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs/env_config"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/app"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/database/repository/connection_control"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/web_api"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_validators.git"
	"gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/publisher_by_http_handler"
	handlers "gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/service"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_writeoff_web_publisher/service"
)

func main() {
	gocore_validators.InitializeCustomValidators()

	serviceWorker := app.NewServerScript()
	serviceWorker.InitConfigManagerDefault()
	conf := env_config.GetCommonEnvConfigs()
	extraConfig := service.NewExtraConfigs()
	clickInfoConfig := service.NewClickInfoConfigStruct()
	worldLostPostGoodsLostHandler := service.NewWorldLostPostGoodsLostHandler(extraConfig, clickInfoConfig)
	worldLostPostGoodsPostHandler := service.NewWorldLostPostGoodsPostHandler(extraConfig, clickInfoConfig)

	handler := publisher_by_http_handler.GetHandlerHttpRegistration(
		map[string]handlers.SyncHttpApi{
			"world.sync.v1.lostpost.goods.lost.by_office.publisher": worldLostPostGoodsLostHandler,
			"world.sync.v1.lostpost.goods.post.by_office.publisher": worldLostPostGoodsPostHandler,
		},
	)
	serviceWorker.Configuration(
		extraConfig.Configure,
		connection_control.InitConnections(conf),
		handler.StartSync,
		clickInfoConfig.Configure,
	)
	serviceWorker.Tasks(web_api.StartGin(":"+conf.Port, handler.GinHandler()))
	app.StartServer(serviceWorker)
}
