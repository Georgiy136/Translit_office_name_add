package main

import (
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs/env_config"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/app"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/database/repository/connection_control"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/web_api"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_validators.git"
	"gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/publisher_by_http_handler"
	handlers "gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/service"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_goods_web_publisher/service"
)

func main() {
	gocore_validators.InitializeCustomValidators()

	serviceWorker := app.NewServerScript()
	serviceWorker.InitConfigManagerDefault()
	conf := env_config.GetCommonEnvConfigs()
	extraConfig := service.NewExtraConfigs()

	worldDeliveryRoutesHandler := service.NewWorldDeliveryRoutesHandler(extraConfig)

	handler := publisher_by_http_handler.GetHandlerHttpRegistration(
		map[string]handlers.SyncHttpApi{
			"world.sync.v1.goods.excluded_from_sale.publisher": worldDeliveryRoutesHandler,
		},
	)

	serviceWorker.Configuration(
		extraConfig.Configure,
		connection_control.InitConnections(conf),
		handler.StartSync,
	)

	serviceWorker.Tasks(web_api.StartGin(":"+conf.Port, handler.GinHandler()))

	app.StartServer(serviceWorker)
}
