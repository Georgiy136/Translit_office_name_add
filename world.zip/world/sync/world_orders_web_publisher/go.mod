module gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_orders_web_publisher

go 1.24.2

require (
	github.com/gin-gonic/gin v1.10.1
	github.com/go-playground/validator/v10 v10.27.0
	github.com/json-iterator/go v1.1.12
	github.com/sirupsen/logrus v1.9.3
	gitlab.wildberries.ru/wbwh/wh-core/clickhouse.git v1.0.11
	gitlab.wildberries.ru/wbwh/wh-core/gocore-utils-time.git v1.1.1
	gitlab.wildberries.ru/wbwh/wh-core/gocore_auth.git v1.1.4
	gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git v1.1.4
	gitlab.wildberries.ru/wbwh/wh-core/gocore_service_const.git v1.3.3
	gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git v1.3.5
	gitlab.wildberries.ru/wbwh/wh-core/gocore_validators.git v1.0.20
	gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git v1.1.1
	gitlab.wildberries.ru/wbwh/world/models/hello-saas/sync-models.git v1.2.0
	google.golang.org/protobuf v1.36.6
)

require (
	github.com/ClickHouse/clickhouse-go v1.5.4 // indirect
	github.com/alta/protopatch v0.5.3 // indirect
	github.com/andybalholm/brotli v1.2.0 // indirect
	github.com/armon/go-metrics v0.4.1 // indirect
	github.com/beorn7/perks v1.0.1 // indirect
	github.com/bradfitz/gomemcache v0.0.0-20250403215159-8d39553ac7cf // indirect
	github.com/bytedance/sonic v1.13.2 // indirect
	github.com/bytedance/sonic/loader v0.2.4 // indirect
	github.com/caarlos0/env v3.5.0+incompatible // indirect
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/cloudflare/golz4 v0.0.0-20240916140612-caecf3c00c06 // indirect
	github.com/cloudwego/base64x v0.1.5 // indirect
	github.com/denisenkom/go-mssqldb v0.12.3 // indirect
	github.com/fatih/color v1.16.0 // indirect
	github.com/gabriel-vasile/mimetype v1.4.8 // indirect
	github.com/gin-contrib/pprof v1.5.3 // indirect
	github.com/gin-contrib/sse v1.0.0 // indirect
	github.com/go-jose/go-jose/v3 v3.0.4 // indirect
	github.com/go-playground/locales v0.14.1 // indirect
	github.com/go-playground/universal-translator v0.18.1 // indirect
	github.com/goccy/go-json v0.10.5 // indirect
	github.com/gogo/protobuf v1.3.2 // indirect
	github.com/golang-sql/civil v0.0.0-20220223132316-b832511892a9 // indirect
	github.com/golang-sql/sqlexp v0.1.0 // indirect
	github.com/google/uuid v1.6.0 // indirect
	github.com/hashicorp/consul/api v1.32.1 // indirect
	github.com/hashicorp/errwrap v1.1.0 // indirect
	github.com/hashicorp/go-cleanhttp v0.5.2 // indirect
	github.com/hashicorp/go-hclog v1.5.0 // indirect
	github.com/hashicorp/go-immutable-radix v1.3.1 // indirect
	github.com/hashicorp/go-multierror v1.1.1 // indirect
	github.com/hashicorp/go-rootcerts v1.0.2 // indirect
	github.com/hashicorp/golang-lru v1.0.2 // indirect
	github.com/hashicorp/serf v0.10.1 // indirect
	github.com/klauspost/compress v1.18.0 // indirect
	github.com/klauspost/cpuid/v2 v2.2.10 // indirect
	github.com/leodido/go-urn v1.4.0 // indirect
	github.com/lib/pq v1.10.9 // indirect
	github.com/mattn/go-colorable v0.1.13 // indirect
	github.com/mattn/go-isatty v0.0.20 // indirect
	github.com/mitchellh/go-homedir v1.1.0 // indirect
	github.com/mitchellh/mapstructure v1.5.0 // indirect
	github.com/modern-go/concurrent v0.0.0-20180306012644-bacd9c7ef1dd // indirect
	github.com/modern-go/reflect2 v1.0.2 // indirect
	github.com/munnerz/goautoneg v0.0.0-20191010083416-a7dc8b61c822 // indirect
	github.com/nats-io/nats.go v1.41.1 // indirect
	github.com/nats-io/nkeys v0.4.9 // indirect
	github.com/nats-io/nuid v1.0.1 // indirect
	github.com/nats-io/stan.go v0.10.4 // indirect
	github.com/nu7hatch/gouuid v0.0.0-20131221200532-179d4d0c4d8d // indirect
	github.com/pelletier/go-toml/v2 v2.2.3 // indirect
	github.com/pkg/errors v0.9.1 // indirect
	github.com/prometheus/client_golang v1.22.0 // indirect
	github.com/prometheus/client_model v0.6.2 // indirect
	github.com/prometheus/common v0.62.0 // indirect
	github.com/prometheus/procfs v0.15.1 // indirect
	github.com/rs/dnscache v0.0.0-20230804202142-fc85eb664529 // indirect
	github.com/satori/go.uuid v1.2.0 // indirect
	github.com/twitchyliquid64/golang-asm v0.15.1 // indirect
	github.com/ugorji/go/codec v1.2.12 // indirect
	github.com/valyala/bytebufferpool v1.0.0 // indirect
	github.com/valyala/fasthttp v1.64.0 // indirect
	gitlab.wildberries.ru/wbwh/wh-core/core_hub.git v1.0.2 // indirect
	gitlab.wildberries.ru/wbwh/wh-core/distributed_mutex.git v1.0.4 // indirect
	gitlab.wildberries.ru/wbwh/wh-core/gocore_auth_hmac.git v1.1.1 // indirect
	gitlab.wildberries.ru/wbwh/wh-core/gocore_http.git v1.0.22 // indirect
	gitlab.wildberries.ru/wbwh/wh-core/gocore_utils.git v1.0.43 // indirect
	gitlab.wildberries.ru/wbwh/wh-core/gocore_wb_marking.git v1.3.4 // indirect
	gitlab.wildberries.ru/wbwh/wh-core/stan_wrapper.git v1.0.1 // indirect
	gitlab.wildberries.ru/wbwh/wh-core/whsync_core.git v1.1.2 // indirect
	go.uber.org/automaxprocs v1.6.0 // indirect
	golang.org/x/arch v0.16.0 // indirect
	golang.org/x/crypto v0.40.0 // indirect
	golang.org/x/exp v0.0.0-20250305212735-054e65f0b394 // indirect
	golang.org/x/net v0.42.0 // indirect
	golang.org/x/sync v0.16.0 // indirect
	golang.org/x/sys v0.34.0 // indirect
	golang.org/x/text v0.27.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
