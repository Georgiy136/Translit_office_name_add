package main

import (
	"context"
	"github.com/go-playground/validator/v10"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs/env_config"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/app"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/database/repository/connection_control"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/web_api"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_validators.git"
	"gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/publisher_by_http_batcher"
	handlers "gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/service"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_orders_web_publisher/entries"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_orders_web_publisher/service"
)

func main() {
	var v = validator.New()
	gocore_validators.InitializeCustomValidators()
	gocore_validators.InitializeCustomValidatorsV10(v)

	serviceWorker := app.NewServerScript()
	serviceWorker.InitConfigManagerDefault()
	conf := env_config.GetCommonEnvConfigs()

	var publisher publisher_by_http_batcher.HandlerRegistration
	serviceWorker.Configuration(
		connection_control.InitConnections(conf),
		func(ctx context.Context, config configs.Config) {
			e := entries.New(config)

			publisher = publisher_by_http_batcher.GetHandlerHttpRegistration(map[string]handlers.SyncHttpApi{
				"world.sync.v1.wh.goods.ordered.rejected.publisher":  service.NewWorldSyncV1WhGoodsOrderedRejected(e, v),
				"world.sync.v1.wh.goods.ordered.completed.publisher": service.NewWorldSyncV1WhGoodsOrderedCompleted(e, v),
			})
			publisher.StartSync(ctx, config)
		},
	)

	serviceWorker.Tasks(web_api.StartGin(":"+conf.Port, publisher.GinHandler()))

	app.StartServer(serviceWorker)
}
