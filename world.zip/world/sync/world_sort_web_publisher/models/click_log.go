package models

type ExportLog struct {
	Dt          string `clickhouse:"dt,datetime" json:"dt"`
	WbwhArea    string `clickhouse:"wbwh_area" json:"wbwh_area"`
	WbwhProduct string `clickhouse:"wbwh_product" json:"wbwh_product"`
	ServerKey   string `clickhouse:"server_key" json:"server_key"`
	Datasource  string `clickhouse:"datasource" json:"datasource"`
	ChannelName string `clickhouse:"channel_name" json:"channel_name"`
	JSONBytes   string `clickhouse:"json_bytes" json:"json_bytes"`
}
