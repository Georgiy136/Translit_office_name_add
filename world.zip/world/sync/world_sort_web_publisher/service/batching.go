package service

import (
	"fmt"

	"gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/models"
	"google.golang.org/protobuf/proto"
)

const maxSortRecordsPerMessage = 100

func buildSortBatches[T any](
	data []T,
	keyShard string,
	buildMessage func([]T) proto.Message,
) ([]models.RequestDataWithSharding, error) {
	result := make([]models.RequestDataWithSharding, 0, (len(data)+maxSortRecordsPerMessage-1)/maxSortRecordsPerMessage)
	for start := 0; start < len(data); start += maxSortRecordsPerMessage {
		end := min(start+maxSortRecordsPerMessage, len(data))
		raw, err := proto.Marshal(buildMessage(data[start:end]))
		if err != nil {
			return nil, fmt.Errorf("marshal sort batch: %w", err)
		}
		result = append(result, models.RequestDataWithSharding{
			ResponseBatchData: [][]byte{raw},
			KeyShard:          map[string]struct{}{keyShard: {}},
		})
	}
	return result, nil
}
