package service

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"io"
	"net/http"
	"strings"

	"gitlab.wildberries.ru/wbwh/wh-core/clickhouse.git"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore-utils-time.git/local"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs/env_config"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_const.git/constants"
	"gitlab.wildberries.ru/wbwh/wh-core/whsync_core.git/sync_utils"
	"gitlab.wildberries.ru/wbwh/wh-core/whsync_core.git/wbsync_models"
	clickmodels "gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_sort_web_publisher/models"

	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
	"github.com/gin-gonic/gin/codec/json"
	jsoniter "github.com/json-iterator/go"
	"github.com/sirupsen/logrus"
)

var ErrHeadersNotFound = errors.New("headers not found")

type sortJSONBinding struct{}

func (sortJSONBinding) Name() string { return "json" }

func (sortJSONBinding) Bind(request *http.Request, value any) error {
	if request == nil || request.Body == nil {
		return errors.New("invalid request")
	}
	return decodeSortJSON(request.Body, value)
}

func (sortJSONBinding) BindBody(body []byte, value any) error {
	return decodeSortJSON(bytes.NewReader(body), value)
}

func decodeSortJSON(reader io.Reader, value any) error {
	decoder := json.API.NewDecoder(reader)
	if binding.EnableDecoderUseNumber {
		decoder.UseNumber()
	}
	if binding.EnableDecoderDisallowUnknownFields {
		decoder.DisallowUnknownFields()
	}
	return decoder.Decode(value)
}

func GetRequestedWorldEntryAndWorldTime(ctx *gin.Context) (string, string) {
	if ctx.GetHeader(constants.HeaderWBWHArea) == "" || ctx.GetHeader(constants.HeaderWBWHProduct) == "" {
		return "", local.NowLocalRFC3339Nano()
	}
	return strings.Join([]string{ctx.GetHeader(constants.HeaderWBWHArea), ctx.GetHeader(constants.HeaderWBWHProduct)}, "."), local.NowLocalRFC3339Nano()
}

func GetServiceZoneCountryRegion() (wbsync_models.WBSync_Msg_CountryZone, wbsync_models.WBSync_Msg_CountryRegion, wbsync_models.WBSync_Msg_CountryCode) {
	return sync_utils.GetServiceZone(), sync_utils.GetServiceRegion(), sync_utils.GetServiceCountry()
}

type LoginEntryMap map[string]string

type EntriesConfig struct {
	ChannelMap map[string]LoginEntryMap
}

type DatabaseSyncIdLoginsMap map[string]struct{}

type DatabaseSyncIdLoginsConfig struct {
	DatabaseSyncIdLogins []string `json:"logins"`
}

type ExtraConfigs struct {
	entriesConfig           EntriesConfig
	databaseSyncIdLoginsMap DatabaseSyncIdLoginsMap
}

func NewExtraConfigs() *ExtraConfigs {
	return &ExtraConfigs{}
}

func (c *ExtraConfigs) Configure(_ context.Context, cfg configs.Config) {
	isExist, rawEntries := cfg.GetByServiceKey("entries")
	if !isExist {
		logrus.Panic("no entries config")
	}

	var entriesConfig EntriesConfig
	err := jsoniter.Unmarshal(rawEntries, &entriesConfig.ChannelMap)
	if err != nil {
		logrus.Panicf("can't unmarshal entries config: %v", err)
	}
	c.entriesConfig = entriesConfig
}

func (c *ExtraConfigs) CheckEntries(channel string, login string, worldEntry string) bool {
	entry, exists := c.entriesConfig.ChannelMap[channel][login]
	if exists {
		if entry != worldEntry {
			return false
		}
	}
	return exists
}

func (c *ExtraConfigs) CheckLoginForDatabaseID(login string) bool {
	_, exists := c.databaseSyncIdLoginsMap[login]
	return exists
}

func SendDataForClickLogs[T any](
	req T,
	g *gin.Context,
	channel string,
) error {
	config := env_config.GetCommonEnvConfigs()
	raw, err := jsoniter.Marshal(req)
	if err != nil {
		return fmt.Errorf("cannot marshal data for click: %w", err)
	}
	if err = clickhouse.Save(
		"world_log_clickhouse_db",
		"direct_log.wh_world_log_sync_export_buf",
		channel,
		[]clickmodels.ExportLog{
			{
				ChannelName: channel,
				WbwhArea:    g.GetHeader(constants.HeaderWBWHArea),
				WbwhProduct: g.GetHeader(constants.HeaderWBWHProduct),
				ServerKey:   config.ServerKey,
				Datasource:  config.ServiceName,
				Dt:          local.NowLocalRFC3339Nano(),
				JSONBytes:   string(raw),
			},
		},
	); err != nil {
		return fmt.Errorf("cannot send data for click: %w", err)
	}
	return nil
}
