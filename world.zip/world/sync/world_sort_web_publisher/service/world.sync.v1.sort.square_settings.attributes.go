package service

import (
	"fmt"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/gin-gonic/gin/binding"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_auth.git"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_const.git/constants"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/rest_data"
	"gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/models"
	v001 "gitlab.wildberries.ru/wbwh/world/models/sprut-streams/sort/sync-models.git/v001"
	"google.golang.org/protobuf/proto"
)

type WorldSortSquareSettingsAttributesHandler struct {
	extraConfigs *ExtraConfigs
	channelName  string
}

func NewWorldSortSquareSettingsAttributesHandler(extraConfigs *ExtraConfigs) *WorldSortSquareSettingsAttributesHandler {
	return &WorldSortSquareSettingsAttributesHandler{
		extraConfigs: extraConfigs,
		channelName:  "world.sync.v1.sort.square_settings.attributes",
	}
}

func (w *WorldSortSquareSettingsAttributesHandler) GetDataForSync(g *gin.Context) ([]models.RequestDataWithSharding, error) {
	worldEntry, worldDate := GetRequestedWorldEntryAndWorldTime(g)
	if worldEntry == "" {
		cErr := rest_data.NewCustomError(ErrHeadersNotFound, "header.not_found", "required headers not found",
			fmt.Sprintf("required headers: %s, %s", constants.HeaderWBWHProduct, constants.HeaderWBWHArea), http.StatusBadRequest)
		g.AbortWithStatusJSON(http.StatusBadRequest, cErr)
		return nil, fmt.Errorf("%s or %s not found", constants.HeaderWBWHArea, constants.HeaderWBWHProduct)
	}

	login, err := gocore_auth.GetLoginFromBasicAuth(g)
	if err != nil {
		cErr := rest_data.NewCustomError(err, "login.not_found", "login not found", "", http.StatusUnauthorized)
		g.AbortWithStatusJSON(http.StatusUnauthorized, cErr)
		return nil, fmt.Errorf("[%s] can't get login: %w", w.channelName, err)
	}

	if !w.extraConfigs.CheckEntries(w.channelName, login, worldEntry) {
		cErr := rest_data.NewCustomError(nil, "login.entry.not_found", "no entry for this login and headers", "", http.StatusUnauthorized)
		g.AbortWithStatusJSON(http.StatusUnauthorized, cErr)
		return nil, fmt.Errorf("[%s] no entry for this login and headers", w.channelName)
	}

	var request v001.WorldSortSquareSettingsAttributes
	if err = g.ShouldBindBodyWith(&request.Data, sortJSONBinding{}); err != nil {
		cErr := rest_data.NewCustomError(err, "validation.error", "body validation error",
			fmt.Sprintf("failed to bind body: %v", err), http.StatusBadRequest)
		g.AbortWithStatusJSON(http.StatusBadRequest, cErr)
		return nil, fmt.Errorf("[%s] can not parse body: %w", w.channelName, err)
	}

	for _, item := range request.Data {
		if item == nil {
			err := fmt.Errorf("data contains a null record")
			g.AbortWithStatusJSON(http.StatusBadRequest, rest_data.NewCustomError(err, "validation.error", err.Error(), "", http.StatusBadRequest))
			return nil, err
		}
	}
	if err = binding.Validator.ValidateStruct(&request); err != nil {
		g.AbortWithStatusJSON(http.StatusBadRequest, rest_data.NewCustomError(err, "validation.error", "body validation error", err.Error(), http.StatusBadRequest))
		return nil, err
	}
	for i := range request.Data {
		request.Data[i].WorldEntry = worldEntry
		request.Data[i].WorldReportedDt = worldDate
	}

	result, err := buildSortBatches(
		request.Data,
		strings.ReplaceAll(g.GetHeader(constants.HeaderWBWHArea), ".", "_"),
		func(batch []*v001.WorldSortSquareSettingsAttributes_SquareSetting) proto.Message {
			return &v001.WorldSortSquareSettingsAttributes{Data: batch}
		},
	)
	if err != nil {
		cErr := rest_data.NewCustomError(err, "internal.service_error", "internal service error",
			fmt.Sprintf("failed to prepare batches: %s", err), http.StatusInternalServerError)
		g.AbortWithStatusJSON(http.StatusInternalServerError, cErr)
		return nil, fmt.Errorf("[%s] can't prepare batches: %w", w.channelName, err)
	}
	if err = SendDataForClickLogs(&request, g, w.channelName); err != nil {
		cErr := rest_data.NewCustomError(err, "internal.service_error", "internal service error",
			fmt.Sprintf("failed to log request: %s", err), http.StatusInternalServerError)
		g.AbortWithStatusJSON(http.StatusInternalServerError, cErr)
		return nil, fmt.Errorf("[%s] can't log request: %w", w.channelName, err)
	}
	return result, nil
}
