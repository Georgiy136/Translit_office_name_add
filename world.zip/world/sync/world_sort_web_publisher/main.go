package main

import (
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_configs.git/configs/env_config"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/app"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/database/repository/connection_control"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/web_api"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_validators.git"
	"gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/publisher_by_http_handler"
	handlers "gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/service"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_sort_web_publisher/service"
)

// приёмная точка мирового контура для каналов сортировки
//
// крутится на страновом World, принимает http
// от WhSprutStreamsExportToWorld своей страны, сверяет логин с world_entries,
// проставляет world_entry и world_reported_dt, пишет в stan_sort_infile01
//
// дальше ReplicatorStanInfile01ToLTExport увозит в хаб, а оттуда в РФ
func main() {
	gocore_validators.InitializeCustomValidators()

	serviceWorker := app.NewServerScript()
	serviceWorker.InitConfigManagerDefault()
	conf := env_config.GetCommonEnvConfigs()
	extraConfig := service.NewExtraConfigs()

	squareSettingsAttributes := service.NewWorldSortSquareSettingsAttributesHandler(extraConfig)
	directionSsq := service.NewWorldSortDirectionSsqHandler(extraConfig)
	directionPsq := service.NewWorldSortDirectionPsqHandler(extraConfig)

	handler := publisher_by_http_handler.GetHandlerHttpRegistration(
		map[string]handlers.SyncHttpApi{
			"world.sync.v1.sort.square_settings.attributes.publisher": squareSettingsAttributes,
			"world.sync.v1.sort.direction.ssq.publisher":              directionSsq,
			"world.sync.v1.sort.direction.psq.publisher":              directionPsq,
		},
	)

	serviceWorker.Configuration(
		extraConfig.Configure,
		connection_control.InitConnections(conf),
		handler.StartSync,
	)

	serviceWorker.Tasks(web_api.StartGin(":"+conf.Port, handler.GinHandler()))

	app.StartServer(serviceWorker)
}
