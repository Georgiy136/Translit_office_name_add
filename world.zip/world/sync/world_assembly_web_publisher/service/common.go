package service

type ShardStruct struct {
	DstCountry string
	SrcCountry string
	ScCountry  string
}
