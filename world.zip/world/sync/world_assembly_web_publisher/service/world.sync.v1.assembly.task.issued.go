package service

import (
	"errors"
	"fmt"
	"github.com/go-playground/validator/v10"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore-utils-time.git/local"
	"google.golang.org/protobuf/proto"
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_auth.git"
	"gitlab.wildberries.ru/wbwh/wh-core/gocore_service_core.git/rest_data"
	"gitlab.wildberries.ru/wbwh/wh-core/wbsync_publisher_core.git/publisher_core/models"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_assembly_web_publisher/clickhouse_logger"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_assembly_web_publisher/entries"
	"gitlab.wildberries.ru/wbwh/world/backend/sync.git/world_assembly_web_publisher/utils"
	v001 "gitlab.wildberries.ru/wbwh/world/models/sprut-streams/assembly/sync-models.git/v001"
)

type WorldAssemblyTaskIssuedV1 struct {
	entries    *entries.Entries
	v          *validator.Validate
	dataSource string
	channelKey string
}

func NewWorldAssemblyTaskIssuedV1(e *entries.Entries, v *validator.Validate) *WorldAssemblyTaskIssuedV1 {
	return &WorldAssemblyTaskIssuedV1{
		entries:    e,
		v:          v,
		channelKey: "world.sync.v1.assembly.task.issued",
	}
}

func (s *WorldAssemblyTaskIssuedV1) GetDataForSync(ctx *gin.Context) ([]models.RequestDataWithSharding, error) {
	login, aErr := gocore_auth.GetLoginFromBasicAuth(ctx)
	if aErr != nil {
		cErr := rest_data.NewCustomError(aErr, "login.not_found", "login not found", "", http.StatusUnauthorized)
		ctx.AbortWithStatusJSON(http.StatusUnauthorized, cErr)
		return nil, fmt.Errorf("[%s] failed to get login: %w", s.channelKey, aErr)
	}

	entry, exists := s.entries.Get(s.channelKey, login)
	if !exists {
		cErr := rest_data.NewCustomError(nil, "login.entry.not_found", "no entry for this login", "", http.StatusUnprocessableEntity)
		ctx.AbortWithStatusJSON(http.StatusUnprocessableEntity, cErr)
		return nil, fmt.Errorf("[%s] no entry for login %s", s.channelKey, login)
	}
	worldEntry := utils.GetRequestedWorldEntry(ctx)
	if worldEntry != entry {
		cErr := rest_data.NewCustomError(nil, "login.entry.not_match", "world entry headers value doesn't match allowed", "", http.StatusUnprocessableEntity)
		ctx.AbortWithStatusJSON(http.StatusUnprocessableEntity, cErr)
		return nil, fmt.Errorf("[%s] world entry headers value doesn't match allowed %s", s.channelKey, worldEntry)
	}

	var request v001.WorldAssemblyTasksIssued
	if err := ctx.ShouldBindBodyWithJSON(&request.Data); err != nil {
		cErr := rest_data.NewCustomError(err, "validation.error", "body validation error", fmt.Sprintf("failed to bind body: %v", err), http.StatusBadRequest)
		ctx.AbortWithStatusJSON(http.StatusBadRequest, cErr)
		return nil, fmt.Errorf("[%s] failed to bind body: %w", s.channelKey, err)
	}

	if len(request.Data) == 0 {
		cErr := rest_data.NewCustomError(errors.New("empty body"), "validation.error", "body empty", "", http.StatusBadRequest)
		ctx.AbortWithStatusJSON(http.StatusBadRequest, cErr)
		return nil, fmt.Errorf("[%s] get empty body", s.channelKey)
	}

	if err := s.v.Struct(&request); err != nil {
		cErr := rest_data.NewCustomError(err, "validation.error", "body validation error", fmt.Sprintf("failed to validate body: %v", err), http.StatusBadRequest)
		ctx.AbortWithStatusJSON(http.StatusBadRequest, cErr)
		return nil, fmt.Errorf("[%s] failed to bind body: %w", s.channelKey, err)
	}

	msgsByCountries := make(map[ShardStruct][]*v001.WorldAssemblyTasksIssued_Item)

	for i := range request.Data {
		shard := ShardStruct{
			DstCountry: strings.ToUpper(request.Data[i].DstCountryCode),
			SrcCountry: strings.ToUpper(request.Data[i].SrcCountryCode),
		}
		msgsByCountries[shard] = append(msgsByCountries[shard], request.Data[i])

		request.Data[i].WorldEntry = entry
		request.Data[i].WorldReportedDt = local.NowLocalRFC3339Nano()
	}

	if err := clickhouse_logger.LogIntoClick(&request, utils.GetReqXWhArea(ctx), utils.GetReqXWhProduct(ctx), s.channelKey); err != nil {
		cErr := rest_data.NewCustomError(err, "internal.service_error", "internal service error", fmt.Sprintf("failed to log request: %s", err), http.StatusInternalServerError)
		ctx.AbortWithStatusJSON(http.StatusInternalServerError, cErr)
		return nil, fmt.Errorf("[%s] failed to marhal body: %w", s.channelKey, err)
	}

	shardingData := make([]models.RequestDataWithSharding, 0, len(msgsByCountries))
	for countryShards, data := range msgsByCountries {
		rawData, err := proto.Marshal(&v001.WorldAssemblyTasksIssued{Data: data})
		if err != nil {
			return nil, fmt.Errorf("failed to marshal data: %w", err)
		}

		dataWithSharding := models.RequestDataWithSharding{
			ResponseBatchData: [][]byte{rawData},
			KeyShard: map[string]struct{}{
				strings.ReplaceAll(utils.GetReqXWhArea(ctx), ".", "_"): {},
			},
		}
		if len(countryShards.DstCountry) != 0 {
			dataWithSharding.KeyShard[utils.MakeDstCountryShard(countryShards.DstCountry)] = struct{}{}
		}
		if len(countryShards.SrcCountry) != 0 {
			dataWithSharding.KeyShard[utils.MakeSrcCountryShard(countryShards.SrcCountry)] = struct{}{}
		}
		if len(countryShards.ScCountry) != 0 {
			dataWithSharding.KeyShard[utils.MakeScCountryShard(countryShards.ScCountry)] = struct{}{}
		}

		shardingData = append(shardingData, dataWithSharding)
	}
	return shardingData, nil
}
