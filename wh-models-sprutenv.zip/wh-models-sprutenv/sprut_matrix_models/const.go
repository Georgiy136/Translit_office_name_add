package sprut_matrix_models

const (
	SprutMatrixChannel                   = "sprut.matrix.channel"
	SprutMatrixUpdateNotificationChannel = "sprut.matrix.update.notification.channel"
	OfficeAddOperation                   = 1
	OfficeDeleteOperation                = 2
)
