package v001

import _ "embed"

//go:embed wh_changes.avsc
var WhChangesAvroSchema string
