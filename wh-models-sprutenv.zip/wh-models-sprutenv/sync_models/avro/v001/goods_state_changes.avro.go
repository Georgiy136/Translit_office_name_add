package v001

import _ "embed"

//go:embed goods_state_changes.avsc
var GoodsStateChangesAvroSchema string
