module gitlab.wildberries.ru/wbwh/models/sprut-models/sprutenv/wh-models-sprutenv.git

go 1.26.5

require (
	github.com/alta/protopatch v0.5.3
	github.com/gogo/protobuf v1.3.2
	google.golang.org/protobuf v1.36.11
)
