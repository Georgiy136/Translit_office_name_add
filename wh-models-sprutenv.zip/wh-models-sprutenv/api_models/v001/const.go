package api_models

const (
	WhSprutenvStorageplaceInfoV001                             = "wh.sprutenv.storageplace.info/v001"
	WhSprutenvPhysicalOfficesGetV001                           = "wh.sprutenv.physical_offices.get/v001"
	WhSprutenvPhysicalOfficesShortGetV001                      = "wh.sprutenv.physical_offices.short.get/v001"
	WhSprutenvOfficeStagepartGetByWh                           = "wh.sprutenv.office.stagepart.get.by_wh/v001"
	WhSprutenvSectionsInfoGetByWhV001                          = "wh.sprutenv.sections.info.get.by_wh/v001"
	WhSprutenvOfficeStagepartGetByOffice                       = "wh.sprutenv.office.stagepart.get.by_office/v001"
	WhSprutenvStoragePlacesInfoGetBySections                   = "wh.sprutenv.storageplaces.info.get.by_sections/v001"
	WhSprutenvAdministrationSprutOfficeAdd                     = "wh.sprutenv.administration.sprut_office.add/v001"
	WhSprutenvAdministrationWhAdd                              = "wh.sprutenv.administration.wh.add/v001"
	WhSprutenvAdministrationWhDelete                           = "wh.sprutenv.administration.wh.delete/v001"
	WhSprutenvAdministrationStageAdd                           = "wh.sprutenv.administration.stage.add/v001"
	WhSprutenvOfficeMatrixGet                                  = "wh.sprutenv.office_matrix.get/v001"
	WhSprutenvSprutNamesGet                                    = "wh.sprutenv.sprut_names.get/v001"
	WhSprutenvSprutOfficeExists                                = "wh.sprutenv.sprut_office.exists/v001"
	WhSprutenvPenaltiesSettingsGet                             = "wh.sprutenv.penalties.settings.get/v001"
	WhSprutenvPenaltiesSettingUpdate                           = "wh.sprutenv.penalties.setting.update/v001"
	SprutenvAdministrationStickersGet                          = "sprutenv.administration.stickers.get/v001"
	SprutenvAdministrationTOTStickersGetForPrint               = "sprutenv.administration.tot_stickers.get_for_print/v001"
	SprutenvAdministrationStorageplacesGetByWh                 = "sprutenv.administration.storageplaces.get_by_wh/v001"
	SprutenvAdministrationStagepartCreate                      = "sprutenv.administration.stagepart.create/v001"
	WhSprutenvSkudGet                                          = "wh.sprutenv.skud.get/v001"
	SprutenvSkudSecurityGet                                    = "sprutenv.skud.security.get/v001"
	SprutenvSkudEntrydeviceSecurityCreate                      = "sprutenv.skud.entrydevice.security.create/v001"
	WhSprutenvSkudEntrydeviceCreate                            = "wh.sprutenv.skud.entrydevice.create/v001"
	SprutenvOfficeStreetsGetByStageV001                        = "sprutenv.office.streets.get_by_stage/v001"
	SprutenvAdministrationAccessGetV001                        = "sprutenv.administration.access.get/v001"
	WhSprutenvSkudEntrydeviceGetByWh_v001                      = "sprutenv.skud.entrydevice.get_by_wh/v001"
	SprutenvSkudEntrydeviceSecurityGetByWh                     = "sprutenv.skud.entrydevice.security.get_by_wh/v001"
	SprutenvAsmpacktableGetByWhV001                            = "sprutenv.asmpacktable.get_by_wh/v001"
	SprutenvStorageplaceRejectedGoodsDiscardingTareInfoGetV001 = "sprutenv.storageplace.rejected_goods_discarding.tare_info_get/v001"

	SprutenvStoragePlacesInfoGetBySectionsExternalV001 = "sprutenv.storageplaces.info.get.by_sections/external/v001"

	SprutenvPrintedPlaceStickerAddV001 = "sprutenv.printed_place_sticker.add/v001"

	WhSprutenvStageStreetUpsertInner = "/api/wh.sprutenv.stage.street.upsert/inner/v001"

	SprutenvAdministrationWhTypeUpdate     = "sprutenv.administration.wh_type.update/v001"
	SprutenvAdministrationWhDeactivate     = "sprutenv.administration.wh.deactivate/v001"
	SprutenvStoragePlaceGetByWhStageStreet = "sprutenv.storageplace.get_by_wh_stage_street/v001"

	SprutenvStagepartSettingsTransferWhForStock = "sprutenv.stagepart.settings.transfer.wh.for_stock/v001"
)
