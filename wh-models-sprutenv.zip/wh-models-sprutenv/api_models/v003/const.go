package api_models

const (
	WhSprutenvAdministrationWhAdd                = "sprutenv.administration.wh.add/v003"
)
