package api_models

const (
	SprutenvStagepartSettingsDeleteV002     = "sprutenv.stagepart.settings.delete/v002"
	SprutenvAdminTOTStickersGetForPrintV002 = "sprutenv.administration.tot_stickers.get_for_print/v002"
	TotTareType                             = "TOT"
)
