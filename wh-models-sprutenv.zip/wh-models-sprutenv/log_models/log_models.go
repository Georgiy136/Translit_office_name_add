package log_models

import "time"

type WhSprutenvStorageplaceInfoV001 struct {
	Dt           time.Time `clickhouse:"dt"`
	Api          *string   `clickhouse:"api"`
	ServiceName  *string   `clickhouse:"service_name"`
	ServerKey    *string   `clickhouse:"server_key"`
	EmployeeID   *int64    `clickhouse:"employee_id"`
	Request      []byte    `clickhouse:"request"`
	Response     []byte    `clickhouse:"response"`
	ResponseCode *int      `clickhouse:"response_code"`
}
